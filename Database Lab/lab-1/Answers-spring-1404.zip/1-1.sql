ALTER TABLE Students 
	ADD passedunit	int