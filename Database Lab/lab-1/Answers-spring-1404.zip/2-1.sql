SELECT DISTINCT TC.StudentID
FROM Taken_Courses TC
WHERE TC.CourseID IN (SELECT P.CourseID FROM Prerequisites P)
AND NOT EXISTS (
    SELECT 1
    FROM Prerequisites PR
    WHERE PR.CourseID = TC.CourseID
    AND PR.PrereqID IN (
        SELECT TC2.CourseID
        FROM Taken_Courses TC2
        WHERE TC2.StudentID = TC.StudentID
    )
);
