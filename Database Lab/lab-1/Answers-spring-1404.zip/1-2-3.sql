CREATE TABLE Taken_Courses
(
	CourseID int,
	FOREIGN KEY (CourseID) REFERENCES Courses(ID),
	StudentID char(7),
	FOREIGN KEY (StudentID) REFERENCES Students(StudentNumber),
	Year char(4) Not null,
	Semester varchar(5) not null,
	Grade int
);