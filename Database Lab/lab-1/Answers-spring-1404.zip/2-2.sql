select p1.courseid , p2.prereqID   from Prerequisites as p1
join Prerequisites as p2 on p1.prereqID = p2.courseID 