UPDATE Taken_Courses 
SET Grade = CAST(Grade AS int) + 1
WHERE CourseID IN (
    SELECT Availble_Courses.CourseID
    FROM Availble_Courses 
    WHERE Availble_Courses.TeacherID = 'T006'
);

SELECT * FROM taken_Courses
