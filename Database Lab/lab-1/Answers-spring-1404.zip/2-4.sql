SELECT DISTINCT Courses.TITLE
FROM Courses
WHERE Courses.ID IN (
	SELECT Availble_Courses.CourseID
	FROM Availble_Courses 
	WHERE Availble_Courses.TeacherID = 'T006'
)