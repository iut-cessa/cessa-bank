CREATE TABLE Availble_Courses
(
	ID int PRIMARY KEY,
	CourseID int,
	FOREIGN KEY (CourseID) REFERENCES Courses(ID),
	Year char(4) Not null,
	Semester varchar(5) not null,
	TeacherID char(7)
	FOREIGN KEY (TeacherID) REFERENCES Teachers(ID),

);