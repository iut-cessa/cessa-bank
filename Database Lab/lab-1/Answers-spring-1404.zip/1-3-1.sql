INSERT INTO Departments
    (Name, ID, Budget, Category)
VALUES
    ('Mech', 'D001', 20000.00, 'Engineering'),
    ('Comp', 'D002', 18000.00, 'Science'),
    ('Civil', 'D003', 15000.00, 'Engineering'),
    ('Phy', 'D004', 13000.00, 'Science'),
    ('Elec', 'D005', 22000.00, 'Engineering'),
    ('Math', 'D006', 12000.00, 'Science'),
    ('Chem', 'D007', 17000.00, 'Engineering'),
    ('Bio', 'D008', 16000.00, 'Science'),
    ('EE', 'D009', 14000.00, 'Engineering'),
    ('Astro', 'D010', 12500.00, 'Science');
