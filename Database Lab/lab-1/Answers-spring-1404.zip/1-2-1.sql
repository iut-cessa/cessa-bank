CREATE TABLE Courses (
    ID int NOT NULL PRIMARY KEY,
    TITLE varchar(50) NOT NULL,
    CREDITS int NOT NULL,
    DepartmentID char(5),
    FOREIGN KEY (DepartmentID) REFERENCES Departments(ID)
);
