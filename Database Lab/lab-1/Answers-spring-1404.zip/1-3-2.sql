INSERT INTO Taken_Courses
    (StudentID, CourseID, Semester, Year, Grade)
VALUES
    ('S001', 1, 'F', '2023', 85.50),
    ('S002', 2, 'S', '2024', 90.00),
    ('S003', 3, 'F', '2023', 78.00),
    ('S004', 4, 'S', '2024', 88.50),
    ('S005', 5, 'F', '2023', 92.00),
    ('S006', 6, 'S', '2024', 80.75),
    ('S007', 7, 'F', '2023', 85.00),
    ('S008', 8, 'S', '2024', 87.25),
    ('S009', 9, 'F', '2023', 91.00),
    ('S010', 10, 'S', '2024', 89.50);

	alter table Taken_courses alter column Grade numeric(4,2)

INSERT INTO Prerequisites
    (CourseID, PrereqID)
VALUES
    (2,1),
    (3,1),
    (4,1),
    (5,3),
    (6,1),
    (7,6),
    (8,7),
    (9,1),
    (10,4),
    (3,2);