CREATE TABLE Prerequisites
(
PrereqID int,
CourseID int,
FOREIGN KEY (CourseID) REFERENCES Courses(ID),
FOREIGN KEY (PrereqID) REFERENCES Courses(ID),
PRIMARY KEY(PrereqID, CourseID),
);