WITH RankedOrders AS (
	SELECT
	SalesPersonID,
	SalesOrderID,
	OrderDate,
	TotalDue,
	ROW_NUMBER() OVER (
	PARTITION BY SalesPersonID
	ORDER BY OrderDate
	) AS rn
	FROM
	Sales.SalesOrderHeader
	WHERE
	SalesPersonID IS NOT NULL
)

SELECT
SalesPersonID,
SalesOrderID,
OrderDate,
TotalDue
FROM
RankedOrders
WHERE
rn = 5;