SELECT
SalesPersonID,
ISNULL([2006], 0) AS Sales_2006,
ISNULL([2007], 0) AS Sales_2007,
ISNULL([2008], 0) AS Sales_2008
FROM (
	SELECT
	SalesPersonID,
	YEAR(OrderDate) AS OrderYear,
	TotalDue
	FROM
	Sales.SalesOrderHeader
) AS SourceData

PIVOT (
SUM(TotalDue)
FOR OrderYear IN ([2006], [2007], [2008])
) AS PivotTable
