
CREATE OR ALTER FUNCTION Sales.customizeName (@CustomerID INT)
RETURNS NVARCHAR(100)
AS
BEGIN
	DECLARE @FirstName NVARCHAR(50)
	DECLARE @LastName NVARCHAR(50)
	DECLARE @FullName NVARCHAR(100)

	SELECT
		@FirstName = p.FirstName,
		@LastName = p.LastName
	FROM Sales.Customer c
	JOIN Person.Person p ON c.PersonID = p.BusinessEntityID
	WHERE c.CustomerID = @CustomerID

	SET @FirstName = (TRIM(ISNULL(@FirstName, '')))
	SET @LastName = (TRIM(ISNULL(@LastName, '')))

	SET @FirstName = UPPER(REPLACE(@FirstName, '0', ''))
	SET @FirstName = UPPER(REPLACE(@FirstName, '1', ''))
	SET @FirstName = UPPER(REPLACE(@FirstName, '2', ''))
	SET @FirstName = UPPER(REPLACE(@FirstName, '3', ''))
	SET @FirstName = UPPER(REPLACE(@FirstName, '4', ''))
	SET @FirstName = UPPER(REPLACE(@FirstName, '5', ''))
	SET @FirstName = UPPER(REPLACE(@FirstName, '6', ''))
	SET @FirstName = UPPER(REPLACE(@FirstName, '7', ''))
	SET @FirstName = UPPER(REPLACE(@FirstName, '8', ''))
	SET @FirstName = UPPER(REPLACE(@FirstName, '9', ''))

	SET @LastName = LOWER(REPLACE(@LastName, '0', ''))
	SET @LastName = LOWER(REPLACE(@LastName, '1', ''))
	SET @LastName = LOWER(REPLACE(@LastName, '2', ''))
	SET @LastName = LOWER(REPLACE(@LastName, '3', ''))
	SET @LastName = LOWER(REPLACE(@LastName, '4', ''))
	SET @LastName = LOWER(REPLACE(@LastName, '5', ''))
	SET @LastName = LOWER(REPLACE(@LastName, '6', ''))
	SET @LastName = LOWER(REPLACE(@LastName, '7', ''))
	SET @LastName = LOWER(REPLACE(@LastName, '8', ''))
	SET @LastName = LOWER(REPLACE(@LastName, '9', ''))

	IF (@FirstName = '' AND @LastName = '')
	SET @FullName = 'client: unknown'
	ELSE
	SET @FullName = 'client: ' + @FirstName + ' ' + @LastName
	RETURN @FullName
END
Go

SELECT Sales.customizeName(26565) AS customizeName
SELECT Sales.customizeName(463) AS customizeName

SELECT c.CustomerID, Sales.customizeName(c.CustomerID) As customizeName
from Sales.Customer c
join Person.Person p on c.PersonID=p.BusinessEntityID
where p.FirstName like 'ma%';
