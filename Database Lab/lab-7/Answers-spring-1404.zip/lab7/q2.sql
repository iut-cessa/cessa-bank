
EXEC sp_configure 'xp_cmdshell', 1 
 GO
 -- To update the currently configured value for this feature.
 RECONFIGURE
 GO 



--DECLARE @FilePath NVARCHAR(500) = 'C:\Users\admin\Desktop\NewProductData.csv';


EXEC xp_cmdshell 'bcp "SELECT o.SalesOrderID, o.ProductID, h.OrderDate, o.OrderQty, o.UnitPrice FROM AdventureWorks2012.Sales.SalesOrderDetail o INNER JOIN AdventureWorks2012.Sales.SalesOrderHeader h ON o.SalesOrderID = h.SalesOrderID WHERE YEAR(h.OrderDate) = 2008 AND MONTH(h.OrderDate) = 7" queryout "C:\Users\z\Desktop\temp.csv" -T -c -t,';



select *
into TempSalesData
from OPENROWSET(
BULK 'C:\Users\admin\Desktop\NewProductData.csv',
SINGLE_CLOB
) as SalesData;

select * from TempSalesData