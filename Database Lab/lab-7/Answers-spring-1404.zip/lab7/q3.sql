create table  XMLTable (
ProductName nvarchar(50),
FirstOrderDate XML null,
TotalOrderQty XML null , 
TotalLine XML null
);

select * from XMLTable
 insert into XMLTable 
 select p.Name as ProductName, 
 (select sum(d.OrderQty) as TotalOrderQty for xml path('')) as TotalOrderQty,
 (select sum(d.LineTotal) as TotalLine for xml path('')) as TotalLine,
 (select min(h.Orderdate) as FirstOrderDate for xml path('')) as FirstOrderDate

 from Production.Product p 
 inner join Sales.SalesOrderDetail d on p.ProductID = d.ProductID
 inner join Sales.SalesOrderHeader h on d.SalesOrderID = h.SalesOrderID
 group by p.Name

 exec xp_cmdshell 'bcp AdventureWorks2012.dbo.XMLTable out "C:\Users\z\Desktop\Q3.txt" -T -q -c -t, ';
