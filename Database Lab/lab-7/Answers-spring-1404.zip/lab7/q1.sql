
create TABLE TempProducts (
ProductID int,
Name nvarchar(50),
ProductNumber nvarchar(50),
ListPrice decimal(8, 2)
);

bulk insert TempProducts
from 'C:\Users\admin\Desktop\NewProductData.csv'
with (
FIELDTERMINATOR = ',',
ROWTERMINATOR = '\n',

firstrow = 2	
);




CREATE TABLE NewProducts
(
ProductID int PRIMARY KEY,
Name nvarchar(50),
ProductNumber nvarchar(50),
ListPrice decimal(8, 2)
);

insert INTO NewProducts (ProductID, Name, ProductNumber, ListPrice)
SELECT T.ProductID, T.Name, T.ProductNumber, T.ListPrice
FROM TempProducts T
left join NewProducts N ON T.ProductID = N.ProductID
WHERE N.ProductID is null;

select * FROM TempProducts
select * FROM NewProducts