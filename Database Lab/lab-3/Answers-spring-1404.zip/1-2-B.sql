use [AdventureWorks2012]
GO
GRANT INSERT ON SCHEMA::[Sales] TO [ROLE3]
GO
use [AdventureWorks2012]
GO
GRANT UPDATE ON SCHEMA::[Sales] TO [ROLE3]
GO
