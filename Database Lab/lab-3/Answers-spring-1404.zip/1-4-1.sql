
USE AdventureWorks2012;
CREATE TABLE Sales.NewProducts (
    ID INT IDENTITY PRIMARY KEY,
    ProductName VARCHAR(50),
    Price DECIMAL(10,2)
);
INSERT INTO Sales.NewProducts (ProductName, Price) 
VALUES ('Laptop', 1200.50), ('Tablet', 550.75);