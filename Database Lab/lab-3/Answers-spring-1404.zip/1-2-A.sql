USE [AdventureWorks2012]
GO
CREATE ROLE [ROLE3]
GO
USE [AdventureWorks2012]
GO
ALTER AUTHORIZATION ON SCHEMA::[db_datareader] TO [ROLE3]
GO
