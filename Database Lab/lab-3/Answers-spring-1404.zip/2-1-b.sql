use [AdventureWorks2012]
GO
GRANT SELECT ON [Sales].[vSalesPerson] TO [ROLE4] WITH GRANT OPTION 
GO
