use [AdventureWorks2012]
GO
DENY SELECT ON [Sales].[SalesPerson] TO [ROLE4]
GO
