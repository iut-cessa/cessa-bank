use [AdventureWorks2012]
GO
GRANT ALTER ON SCHEMA::[Sales] TO [ROLE3]
GO
use [AdventureWorks2012]
GO
GRANT CREATE TABLE TO [ROLE3]
GO
