USE [AdventureWorks2012]
GO
ALTER ROLE [ROLE3] ADD MEMBER [zahra]
GO
