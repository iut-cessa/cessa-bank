CREATE OR ALTER PROCEDURE Sales.manager
@year INT
AS
BEGIN
	SET NOCOUNT ON;

	WITH CustomerOrders AS (
		SELECT
			soh.CustomerID,
			p.FirstName + ' ' + p.LastName AS FullName,
			MONTH(soh.OrderDate) AS OrderMonth,
			COUNT(soh.SalesOrderID) AS OrderCount,
			SUM(soh.TotalDue) AS TotalSum,
			MAX(soh.TotalDue) AS MaxTotalDue
		FROM
			Sales.SalesOrderHeader soh
		JOIN
			Sales.Customer c ON soh.CustomerID = c.CustomerID
		JOIN
			Person.Person p ON c.PersonID = p.BusinessEntityID
		WHERE
			YEAR(soh.OrderDate) = @year
		GROUP BY
			soh.CustomerID, p.FirstName, p.LastName, MONTH(soh.OrderDate)
	),
	FavoriteProducts AS (
		SELECT
			soh.CustomerID,
			MONTH(soh.OrderDate) AS OrderMonth,
			p2.Name AS FavoriteProduct,
			ROW_NUMBER() OVER (PARTITION BY soh.CustomerID, MONTH(soh.OrderDate) ORDER BY SUM(sod.OrderQty) DESC, p2.Name) AS rn
		FROM
			Sales.SalesOrderHeader soh
		JOIN
			Sales.SalesOrderDetail sod ON soh.SalesOrderID = sod.SalesOrderID
		JOIN
			Production.Product p2 ON p2.ProductID = sod.ProductID
		WHERE
			YEAR(soh.OrderDate) = @year
		GROUP BY
			soh.CustomerID, MONTH(soh.OrderDate), p2.Name
	)
	SELECT
		co.CustomerID,
		co.FullName,
		co.OrderMonth,
		co.OrderCount,
		co.TotalSum,
		co.MaxTotalDue,
		fp.FavoriteProduct
	FROM
		CustomerOrders co
	LEFT JOIN
		FavoriteProducts fp ON co.CustomerID = fp.CustomerID AND co.OrderMonth = fp.OrderMonth AND fp.rn = 1
	ORDER BY
		co.OrderMonth, co.CustomerID;
END;

execute Sales.manager 2008;