CREATE TABLE pph (
	ProductId INT,
	Name NVARCHAR(255),
	ListPrice MONEY,
	StartDate DATETIME,
	EndDate DATETIME NULL,
	CurrentFlag BIT
);
GO

INSERT INTO pph (ProductId, Name, ListPrice, StartDate, EndDate, CurrentFlag)
	SELECT p.ProductID, p.Name, p.ListPrice, p.ModifiedDate, NULL, 1
	FROM Production.Product p;
GO

CREATE TRIGGER trgUpdatePrice
ON Production.Product
AFTER UPDATE
AS
BEGIN
	SET NOCOUNT ON;

	IF UPDATE(ListPrice)
	BEGIN
	DECLARE @ProductId INT;

	SELECT  @ProductId = INSERTED.ProductID
	FROM INSERTED;

	UPDATE pph
	SET 
		EndDate = GETDATE(),
		CurrentFlag = 0
	WHERE ProductId = @ProductId  AND CurrentFlag = 1;

	INSERT INTO pph (ProductId, Name, ListPrice, StartDate, EndDate, CurrentFlag)
	SELECT  i.ProductID, i.Name, i.ListPrice, GETDATE(), NULL, 1
	FROM INSERTED i;
	END
END
GO

select *
from pph
where ProductID = 1



update Production.Product
set ListPrice = 500
where ProductID = 1