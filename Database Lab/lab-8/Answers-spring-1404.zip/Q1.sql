BEGIN TRANSACTION;

UPDATE Person.Person
SET FirstName = 'John'
WHERE BusinessEntityID = 1;

UPDATE Person.Person
SET FirstName = 'Jane'
WHERE BusinessEntityID = 2;

SAVE TRANSACTION SavePoint1;

UPDATE Person.Person
SET FirstName = 'Michael'
WHERE BusinessEntityID = 1;

UPDATE Person.Person
SET FirstName = 'Emily'
WHERE BusinessEntityID = 2;

ROLLBACK TRANSACTION SavePoint1;

SELECT BusinessEntityID, FirstName
FROM Person.Person
WHERE BusinessEntityID IN (1, 2);

COMMIT TRANSACTION;
