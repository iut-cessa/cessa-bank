UPDATE Sales.SalesOrderDetail
SET OrderQty = OrderQty + 1
WHERE ProductID = 900;

-- or

DELETE FROM Sales.SalesOrderDetail
WHERE ProductID = 950;
