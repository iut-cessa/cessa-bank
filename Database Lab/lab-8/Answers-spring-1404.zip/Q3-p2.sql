BEGIN TRANSACTION t2

UPDATE Sales.SalesOrderHeader
SET SubTotal = 2
WHERE SalesOrderID = 43659
WAITFOR DELAY '00:00:09'
UPDATE Production.Product
SET Name = 'chiz22'
WHERE ProductID = 1

COMMIT TRANSACTION t2;
