BEGIN TRANSACTION t1

UPDATE Production.Product
SET Name = 'chiz1' 
WHERE ProductID = 1

WAITFOR DELAY '00:00:09'

UPDATE Sales.SalesOrderHeader
SET SubTotal = 1
WHERE SalesOrderID = 43659

COMMIT TRANSACTION t1;
