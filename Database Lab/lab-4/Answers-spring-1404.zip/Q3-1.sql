select SalesPersonID , TotalDue ,
sum(TotalDue) over (partition by SalesPersonID order by TotalDue ROWS BETWEEN 2 PRECEDING AND CURRENT ROW) as RT 
from sales.SalesOrderHeader
order by SalesPersonID