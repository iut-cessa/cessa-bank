select salespersonid , TerritoryID , sum(totaldue) as subtotals, grouping(SalesPersonID)
from sales.SalesOrderHeader
group by grouping sets (SalesPersonID , TerritoryID) 
