select SalesPersonID , TotalDue , 
sum(TotalDue) over (partition by SalesPersonID order by TotalDue ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) as RT 
from sales.SalesOrderHeader
order by SalesPersonID