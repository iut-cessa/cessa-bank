select SalesPersonID , TotalDue , 
sum(TotalDue) over (partition by SalesPersonID order by TotalDue ROWS BETWEEN CURRENT ROW AND 2 following  ) as RT
from sales.SalesOrderHeader
order by SalesPersonID