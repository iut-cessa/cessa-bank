select SalesPersonID , TotalDue , sum(TotalDue) over (partition by SalesPersonID order by TotalDue ROWS BETWEEN CURRENT ROW AND UNBOUNDED  following ) as RT
from sales.SalesOrderHeader
order by SalesPersonID