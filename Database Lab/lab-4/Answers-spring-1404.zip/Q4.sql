select productID , ListPrice , p.ProductSubcategoryID ,
	rank() over (partition by p.ProductSubcategoryID order by p.listprice desc) as rank , 
	percent_rank() over (partition by p.ProductSubcategoryID order by p.listprice desc) as percentRank
from Production.Product p