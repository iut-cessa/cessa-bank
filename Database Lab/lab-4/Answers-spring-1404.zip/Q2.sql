with avgTable(territory, average) as (select distinct TerritoryID, 
avg(TotalDue)
from Sales.SalesOrderHeader
group by TerritoryID)
select * 
from Sales.SalesOrderHeader join avgTable
on Sales.SalesOrderHeader.TerritoryID = avgTable.territory
where avgTable.average < Sales.SalesOrderHeader.TotalDue 