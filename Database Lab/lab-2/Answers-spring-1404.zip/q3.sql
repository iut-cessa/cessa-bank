SELECT sd.ProductID,Production.Product.Name,
CASE
WHEN SUM(CASE WHEN MONTH(sh.DueDate) BETWEEN 1 AND 6 THEN sd.UnitPrice * sd.OrderQty END) >
SUM(CASE WHEN MONTH(sh.DueDate) BETWEEN 7 AND 12 THEN sd.UnitPrice * sd.OrderQty END)
THEN 'dec'
ELSE 'inc'
END AS HigherHalf
FROM Sales.SalesOrderHeader AS sh
LEFT JOIN Sales.SalesOrderDetail AS sd ON sh.SalesOrderID = sd.SalesOrderID
full join Production.Product on sd.ProductID = Product.ProductID
WHERE YEAR(sh.DueDate) IN (2006, 2007)
GROUP BY sd.ProductID , Production.Product.Name