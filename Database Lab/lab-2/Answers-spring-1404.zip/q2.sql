SELECT c.CustomerID, p.Firstname,
case
when sum(soh.TotalDue) IS NULL THEN 0
else sum(soh.TotalDue)
end as spend,
case
when count(soh.SalesOrderID) IS NULL THEN 0
else count(soh.SalesOrderID)
end as numberoforder

From Sales.SalesOrderHeader soh
RIGHT Join Sales.Customer c on soh.CustomerID = c.CustomerID
LEFT Join Person.Person p on c.PersonID =p.BusinessEntityID
Group by c.CustomerID, p.FirstName, p.LastName