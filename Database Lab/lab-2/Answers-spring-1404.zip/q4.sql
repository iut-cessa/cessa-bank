CREATE TABLE Jobs (PersonID INT PRIMARY KEY, JobTitle VARCHAR(100) CHECK (JobTitle in ('Manager', 'Teacher' , 'Student')));

INSERT INTO Jobs (PersonID, JobTitle)
VALUES (1, 'Manager'),
(2, 'Teacher'),
(3, 'Student'),
(4, 'Manager'),
(5, 'Teacher'),
(6, 'Student'),
(7, 'Teacher'),
(8, 'Student');

SELECT (select COUNT(*) FROM Jobs WHERE JobTitle = 'Student') AS 'Student',
(select COUNT(*) FROM Jobs WHERE JobTitle = 'Teacher') AS 'Teacher',
(select COUNT(*) FROM Jobs WHERE JobTitle = 'Manager') AS 'Manager'