select Sales.SalesTerritory.Name, sum(TotalDue) , 
CASE  
WHEN sum(TotalDue)>8500000 THEN 'HIGH'
ELSE  'LOW'
END AS 'compare'
from Sales.SalesOrderHeader as o
inner join Sales.SalesTerritory on Sales.SalesTerritory.TerritoryID = o.TerritoryID
group by (Sales.SalesTerritory.Name) 
having sum(TotalDue) < 10000000
ORDER BY sum(TotalDue) DESC
